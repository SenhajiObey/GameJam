﻿using UnityEngine;
public abstract class GroundCheckBase: MonoBehaviour
{

    public abstract bool isGrounded();
}