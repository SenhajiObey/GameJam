using System;
using UnityEngine.Events;

[Serializable]
public class BatteryEvent : UnityEvent<float>
{

}