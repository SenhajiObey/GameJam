using System;
using UnityEngine.Events;
[Serializable]
public class FlashLightEvent : UnityEvent<float>
{

}
